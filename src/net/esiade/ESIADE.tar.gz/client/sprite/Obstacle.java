package net.esiade.client.sprite;

import net.esiade.client.Vector2D;

public class Obstacle extends StaticSprite {

	public Obstacle(String image, Vector2D position) {
		super(image, position);
		// TODO Auto-generated constructor stub
	}

}
