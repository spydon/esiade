package net.esiade.client.sprite;

import net.esiade.client.Vector2D;


public class Food extends StaticSprite {

	public Food(Vector2D position) {
		super("http://images1.wikia.nocookie.net/__cb20100616103916/frontierville/images/5/50/Swiss_Cheese-icon.png", position);
		// TODO Auto-generated constructor stub
	}

}
